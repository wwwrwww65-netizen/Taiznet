setConfig(document.currentScript,"تم تغيير النص بنجاح")
